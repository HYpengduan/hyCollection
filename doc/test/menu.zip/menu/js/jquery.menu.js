(function($){
	$.extend({
		menu:function(options){
			var defaults = {
				click:null,
				menuContainer:$('#menuContainer'),
				menus:[],
				isExtend:true
			};
			var settings = $.extend({},defaults,options);
			var fn = {
				init:function(s){
					s.menuContainer.empty();
					var html = fn.initView(s.menus);
					s.menuContainer.append($(html));
					fn.initEvent(s.menuContainer,s.click);
				},
				initView:function(menuObj){
					var html = '<ul>';

					$.each(menuObj,function(i,v){
						html += fn.iterateMenu(v);
					});
					html += '</ul>'
					return html;
				},
				iterateMenu:function(menu){
					var html = '<li>'
					if(menu.menuSon && menu.menuSon.length > 0){
						html += '<a class="menu-parent menu-level-'+menu.menu_level+'"><span class="menu-icon menu-icon-open"></span>'+menu.menu_name+'</a><ul>'
							$.each(menu.menuSon,function(i,v){
								html += fn.iterateMenu(v);
							});
						html +=  '</ul></li>';
					}else{
						//html += '<a class=""></a></li>';
						if(menu.menu_level == 1){
							html += '<a class="menu-parent menu-level-'+menu.menu_level+'"><span class="menu-icon menu-icon-close"></span>'+menu.menu_name+'</a></li>';
						}else{
							html += '<a class="menu-leaf" data-id="'+menu.menu_id +'" data-url="'+ menu.menu_url+'">'+menu.menu_name+'</a></li>';
						}
					}

					return html;
				},
				initEvent:function(menuContainer,click){



					menuContainer.find('.menu-parent').each(function(i,v){
						$(v).click(function(){
							var cthis = $(this),menuIcon = cthis.find('.menu-icon');
							if(cthis.next().is(':hidden')){
								cthis.next().slideDown();
								menuIcon.removeClass('menu-icon-close');
								menuIcon.addClass('menu-icon-open');
							}else{
								cthis.next().slideUp();
								menuIcon.removeClass('menu-icon-open');
								menuIcon.addClass('menu-icon-close');
							}
						});
					});

					menuContainer.find('.menu-leaf').each(function(i,v){
						$(v).click(function(){
							menuContainer.find('a.menu-selected').removeClass('menu-selected');
							$(this).addClass('menu-selected');
							if(click){
								click.call(this);
							}
						});
					});

					// menuContainer.on('click','.menu-parent',function(e){
					// 	var cthis = $(this),menuIcon = cthis.find('.menu-icon');
					// 	if(cthis.next().is(':hidden')){
					// 		console.log('hidden');
					// 		cthis.next().slideDown();
							
					// 		menuIcon.removeClass('menu-icon-close');
					// 		menuIcon.addClass('menu-icon-open');
					// 	}else{
					// 		console.log('show');
					// 		cthis.next().slideUp();
					// 		menuIcon.removeClass('menu-icon-open');
					// 		menuIcon.addClass('menu-icon-close');
					// 	}
					// }).on('click','.menu-leaf',function(e){
					// 	menuContainer.find('a.menu-selected').removeClass('menu-selected');
					// 	$(this).addClass('menu-selected');
					// 	if(click){
					// 		click.call(this);
					// 	}
					// });
				}
			};
			fn.init(settings);
		}
	});

})(jQuery);