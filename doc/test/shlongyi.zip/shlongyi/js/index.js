// 获取当前应用的版本号
var wgtVer=null;
function plusReady(){
    // 获取本地应用资源版本号
    plus.runtime.getProperty(plus.runtime.appid,function(inf){
        wgtVer=inf.version;
        checkUpdate();
    });
}
if(window.plus){
    plusReady();
}else{
    document.addEventListener('plusready',plusReady,false);
}

// 发起ajax请求检测是否有新版本
var checkUrl="http://106.14.17.228/lypro/api/app/checkNewVersion";
function checkUpdate(){
    plus.nativeUI.showWaiting("检测更新...");
    var xhr=new XMLHttpRequest();
    xhr.onreadystatechange=function(){
        switch(xhr.readyState){
            case 4:
            plus.nativeUI.closeWaiting();
            if(xhr.status==200){
            	var ret = JSON.parse(xhr.responseText);
                console.log("检测更新成功："+ ret.version);
                var newVer = ret.version;
                if(wgtVer&&newVer&&(wgtVer!=newVer)){
                    plus.nativeUI.confirm("是否立即更新到最新版本？", function(event) {
                        if (event.index) {
                            plus.runtime.quit();
                        } else {
                            downWgt(ret.url);  // 下载升级包
                        }
                    }, {
                        'buttons': ['确定', "取消"]
                    });
                }else{
                    // plus.nativeUI.alert("无新版本可更新！");
                }
            }else{
                console.log("检测更新失败！");
                plus.nativeUI.alert("检测更新失败！");
            }
            break;
            default:
            break;
        }
    }
    xhr.open('POST',checkUrl);
    xhr.send();
}

//从服务器下载应用资源包（wgt文件）
function downWgt(wgtUrl){
    plus.nativeUI.showWaiting("正在下载文件，请稍后...");
    plus.downloader.createDownload( wgtUrl, {filename:"_doc/update/"}, function(d,status){
        if ( status == 200 ) { 
            console.log("新版本下载成功："+d.filename);
            installWgt(d.filename); // 安装wgt包
        } else {
            console.log("新版本下载失败！");
            plus.nativeUI.alert("新版本下载失败！");
        }
        plus.nativeUI.closeWaiting();
    }).start();
}

// 更新应用资源包（wgt文件）
function installWgt(path){
    plus.nativeUI.showWaiting("安装新版本...");
    plus.runtime.install(path,{},function(){
        plus.nativeUI.closeWaiting();
        console.log("安装新版本成功！");
        plus.nativeUI.alert("新版本更新完成！",function(){
            plus.runtime.restart();
        });
    },function(e){
        plus.nativeUI.closeWaiting();
        console.log("安装新版本失败["+e.code+"]："+e.message);
        plus.nativeUI.alert("安装新版本失败["+e.code+"]："+e.message);
    });
}