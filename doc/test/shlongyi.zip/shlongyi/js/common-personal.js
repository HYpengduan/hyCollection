(function ($) {
	$(function () {
		// 页面回退
		$('.back').click(function () {
			var iIndex = $('.back').index($(this));

			$('.page-hide').removeClass('page-show').eq(iIndex-1).addClass('page-show');
		});
	});
})(jQuery);