document.addEventListener("plusready", function() {
	var times = 0;
	var timer = null;
    // 注册返回按键事件
    plus.key.addEventListener('backbutton', function() {
    	if(times >= 1) {
    		clearTimeout(timer);
			// 事件处理
		    plus.nativeUI.confirm("退出程序？", function(event) {
		    	times = 0;
		        if (event.index) {
		        	localStorage.setItem('quitUrl', JSON.stringify({
		        		time: new Date().getTime(),
		        		url: window.location.href
		        	}));
					plus.runtime.quit();
		        }
		    }, {
		    	'buttons': ["取消", '确定']
		    });
    	} else {
    		times++;
    		timer = setTimeout(function () {
    			times = 0;
    			// 事件处理
    			window.history.back();
    		}, 300);
    	}
    	return false;
    }, false);
});