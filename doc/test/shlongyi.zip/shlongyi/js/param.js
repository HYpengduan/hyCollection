/*
	获取参数接口函数
	type: 参数类型
	selectName: 下拉列表Name
	fields: 更多的参数
*/
function getParamValue(type, selectName, fields) {
	fields = fields || {};
	var query = '?sid=' + localStorage.getItem('sid');
	$.post(API.companyParamSelect + query, $.extend({type: type}, fields), function (data) {
		if(data && data.code == 200) {
			for(var i = 0; i < data.data.length; i++) {
				$('<option value="' + (data.data[i].id || data.data[i].value) + '">').html(data.data[i].value).appendTo($('select[name='+selectName+']'));
			}
		}
	}, 'json');
}

/*
	判断必填项字段是否填写
*/
function checkField(fields, formData) {
	var status = true;
	$.each(formData, function (k, v) {
		if($.inArray(v.name, fields) != -1 && (v.value == '' || v.value == '0')) {
			status = false;
			return false;
		}
	});
	return status;
}

/*
	二维数组中取某个字段的和
	arr：便利的数组
	field：指定字段的和
*/
function getFieldSum(arr, field) {
	var ret = 0;
	$.each(arr, function (k ,v) {
		ret += arr[k][field] || 0;
	});
	return ret;
}

/*
	数字货币转换成大写中文货币
*/
function switchMoneyNumberToChinese(money) {
	var number = ['零', '壹','贰','叁','肆','伍','陆','柒','捌','玖'];
	// 层级单位
	var levelUnit = ['元', '万', '亿'];

	// 基础单位
	var baseUnit = ['拾', '佰', '仟'];

	// 小数单位
	var floatUnit = ['角', '分'];

	// 将货币分为整数和小数部分
	var iIntNum = Math.floor(money);
	var fFloatNum = money - iIntNum;

	// 拆分整数部分并翻转
	var aIntNum = String(iIntNum).split('').map(function (v) {
		return Number(v);
	}).reverse();

	// 存储转换后的结果
	var ret = [];
	// 当前值
	var prevNum= 0;
	// 每个层级是否都为0
	var perLevelAllZero = false;
	for(var i = 0; i < aIntNum.length; i++) {

		// 添加单位
		// 判断是否到达某个层级
		if(i % 4 === 0) {
			// 每到达一个层级，就设置当前值为0元
			prevNum= 0;

			// 如果上个层级都为0，则把单位取消
			if(perLevelAllZero){
				ret.pop();
			}
			// 假设当前层级都为0
			perLevelAllZero = true;

			// 添加层级单位
			ret.push(levelUnit[i / 4]);
		} else {
			// 当前如果不为0
			if(Number(aIntNum[i]) !== 0) {
				ret.push(baseUnit[(i-1) % 4]);
				perLevelAllZero = false;
			}
		}

		// 添加数字
		if(aIntNum[i] !== 0 || (prevNum !== 0 && aIntNum[i] === 0)) {
			ret.push(number[aIntNum[i]]);
			// 更新数字
			prevNum = aIntNum[i];
		}
	}

	if(fFloatNum === 0) {
		ret.unshift('整');
	} else {
		// 添加分隔符
		ret.unshift('.');

		// 转换成字符串后切割
		var sMoney = String(money);
		var iPos = sMoney.indexOf('.');
		var aFloatNum = sMoney.slice(iPos + 1,iPos + 3).split('').map(function (v) {
			return Number(v);
		});
		aFloatNum.forEach(function (v, k) {
			ret.unshift(floatUnit[k], number[v]);
		});
	}

	return ret.reverse().join('');
}