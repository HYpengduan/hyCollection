(function ($) {
	$(function () {
		var query = '?sid=' + localStorage.getItem('sid');
		// 显示企业账号
		if($('.user-no').length > 0 || $('.real-name').length > 0) {
			$.post(API.companyUserGetUserInfo + query, function (data) {
				if(data) {
					if(data.code == 200) {
						// 显示用户账号
						$('.user-no').html(data.data.user_no);
						$('.real-name').html(data.data.realname);
					} else if(data.code == 401) {
						Alert.show('请重新登录');
					} else {
						Alert.show(data.codeMessage);
					}
				}
			}, 'json');
		}

		// 页面回退
		$('.back').click(function () {
			var iIndex = $('.back').index($(this));

			$('.page-hide').removeClass('page-show').eq(iIndex-1).addClass('page-show');
		});

		// 获取市区列表
		function selectCities(container, prov_id, fn) {
			var param = 'type=110&up_id=' + prov_id;
			$.post(API.companyParamSelect + query, param, function (data) {
				if(data) {
					if(data.code == 200) {
						var oCity = container;
						oCity.html('<option value="0">请选择</option>');
						$.each(data.data, function (k ,v) {
							oCity.append('<option value="'+ v.id +'">' + v.value + '</option>');
						});
						fn && fn();
					}
				}
			}, 'json');
		}
		window.selectCities = selectCities;

		//获取保险类型列表
		function selectInsurance(container, city_id, fn) {
			var param = 'type=2&up_id=' + city_id;
			$.post(API.companyParamSelect + query, param, function (data) {
				if(data) {
					if(data.code == 200) {
						var oInsurance = container;
						oInsurance.html('<option value="0">请选择</option>');
						$.each(data.data, function (k ,v) {
							oInsurance.append('<option value="'+ v.id +'">' + v.value + '</option>');
						});
						fn && fn();
					}
				}
			}, 'json');
		}
		window.selectInsurance = selectInsurance;

		// 省市联动
		$('body').on('change', 'select[name=prov_id]', function () {
			selectCities($(this.form).find('select[name=city_id]'), $(this).val());
		});

		// 省，市，保险类型联动
		$('body').on('change', 'select[name=city_id]', function () {
			selectInsurance($(this.form).find('select[name=insurance_type]'), $(this).val());
		});
	});
})(jQuery);