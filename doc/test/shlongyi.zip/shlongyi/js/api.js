/*
	定义接口
*/
var API = {
	/* --------------------------- 企业接口 开始 --------------------------- */
	// 企业登录接口
	'companyUserLogin': 'http://106.14.17.228/lypro/api/company/user/login',

	// 企业忘记密码接口
	'companyUserForgetPassword': 'http://106.14.17.228/lypro/api/company/user/forgetPassword',

	// 企业发送验证码接口
	'companyUserSendVerifyCode': 'http://106.14.17.228/lypro/api/company/user/sendVerifyCode',

	// 企业密码重置接口
	'companyUserResetPassword': 'http://106.14.17.228/lypro/api/company/user/resetPassword',

	// 获取用户信息接口
	'companyUserGetUserInfo': 'http://106.14.17.228/lypro/api/company/user/getUserInfo',

	// 留言咨询接口
	'companyUserMessage': 'http://106.14.17.228/lypro/api/company/user/message',

	// 参保信息列表查询接口
	'companyInfoSelect': 'http://106.14.17.228/lypro/api/company/info/select',

	// 参保信息录入接口
	'companyInfoAdd': 'http://106.14.17.228/lypro/api/company/info/add',

	// 参保信息单条查询接口
	'companyInfoFind': 'http://106.14.17.228/lypro/api/company/info/find',

	// 参保信息修改接口
	'companyInfoModify': 'http://106.14.17.228/lypro/api/company/info/modify',

	//参保信息修改复核列表查询接口
	'companyInfoReviewSelect': 'http://106.14.17.228/lypro/api/company/info/review/select',

	// 参保信息修改复核接口
	'companyInfoReviewModify': 'http://106.14.17.228/lypro/api/company/info/review/modify',

	// 工伤信息查询接口
	'companyProcessInjuryJobSelect': 'http://106.14.17.228/lypro/api/company/process/injuryJob/select',

	// 工伤明细查询接口
	'companyProcessInjuryJobFind': 'http://106.14.17.228/lypro/api/company/process/injuryJob/find',

	// 医疗信息查询接口
	'companyProcessCareInfoSelect': 'http://106.14.17.228/lypro/api/company/process/careInfo/select',

	// 医疗明细查询接口
	'companyProcessCareInfoFind': 'http://106.14.17.228/lypro/api/company/process/careInfo/find',

	// 生育信息查询接口
	'companyProcessBirthSelect': 'http://106.14.17.228/lypro/api/company/process/birth/select',

	// 生育明细查询接口
	'companyProcessBirthFind': 'http://106.14.17.228/lypro/api/company/process/birth/find',

	// 社保卡办理信息查询接口
	'companyProcessCardSelect': 'http://106.14.17.228/lypro/api/company/process/card/select',

	// 社保卡办理明细查询接口
	'companyProcessCardFind': 'http://106.14.17.228/lypro/api/company/process/card/find',

	// 社保卡转移信息查询接口
	'companyProcessCardTransferSelect': 'http://106.14.17.228/lypro/api/company/process/cardTransfer/select',

	// 社保卡转移明细查询接口
	'companyProcessCardTransferFind': 'http://106.14.17.228/lypro/api/company/process/cardTransfer/find',

	// 社保明细列表查询接口
	'companySocialSecurityListSelect': 'http://106.14.17.228/lypro/api/company/socialSecurity/list/select',

	// 社保明细信息单条查询接口
	'companySocialSecurityListFind': 'http://106.14.17.228/lypro/api/company/socialSecurity/list/find',

	// 账单查询接口
	'companyBillSelect': 'http://106.14.17.228/lypro/api/company/bill/select',

	// 账单明细查询接口
	'companyBillFind': 'http://106.14.17.228/lypro/api/company/bill/find',

	// 账单明细确认接口
	'companyBillConfirm': 'http://106.14.17.228/lypro/api/company/bill/confirm',

	// 社保查询接口
	'companySocialSecuritySelect': 'http://106.14.17.228/lypro/api/company/socialSecurity/select',

	/* --------------------------- 企业接口 结束 --------------------------- */

	/* --------------------------- 个人接口 开始 --------------------------- */

	// 个人登录接口
	'personUserLogin': 'http://106.14.17.228/lypro/api/person/user/login',

	// 个人注册接口
	'personUserRegister': 'http://106.14.17.228/lypro/api/person/user/register',

	// 个人忘记密码接口
	'personUserForgetPassword': 'http://106.14.17.228/lypro/api/person/user/forgetPassword',

	// 个人发送验证码接口
	'personUserSendVerifyCode': 'http://106.14.17.228/lypro/api/person/user/sendVerifyCode',

	// 密码重置接口
	'personUserResetPassword': 'http://106.14.17.228/lypro/api/person/user/resetPassword',

	// 个人获取用户信息接口
	'personUserGetUserInfo': 'http://106.14.17.228/lypro/api/person/user/getUserInfo',

	// 个人留言咨询接口
	'personUserMessage': 'http://106.14.17.228/lypro/api/person/user/message',

	// 信息查询接口
	'personUserInfo': 'http://106.14.17.228/lypro/api/person/user/info',

	// 工伤明细查询接口
	'personUserInjuryJob': 'http://106.14.17.228/lypro/api/person/user/injuryJob',

	// 医疗明细查询接口
	'personUserCareInfo': 'http://106.14.17.228/lypro/api/person/user/careInfo',

	// 生育明细查询接口
	'personUserBirth': 'http://106.14.17.228/lypro/api/person/user/birth',

	// 社保卡明细查询接口
	'personUserCard': 'http://106.14.17.228/lypro/api/person/user/card',

	// 社保卡转移明细查询接口
	'personUserCardTransfer': 'http://106.14.17.228/lypro/api/person/user/cardTransfer',

	// 社保明细条件查询接口
	'personUserSocialSecurity': 'http://106.14.17.228/lypro/api/person/user/socialSecurity',

	// 社保明细结果查询接口
	'personUserSocialSecurityQuery': 'http://106.14.17.228/lypro/api/person/user/socialSecurity/query',

	/* --------------------------- 个人接口 结束 --------------------------- */

	/* --------------------------- 注销接口 开始 --------------------------- */

	// 企业注销接口
	'companyUserLoginout': 'http://106.14.17.228/lypro/api/company/user/loginout',

	// 个人注销接口
	'personUserLoginout': 'http://106.14.17.228/lypro/api/person/user/loginout',
	/* --------------------------- 注销接口 结束 --------------------------- */

	/* --------------------------- 参数接口 开始 --------------------------- */

	// 参数接口
	'companyParamSelect': 'http://106.14.17.228/lypro/api/company/param/select',

	/* --------------------------- 参数接口 结束 --------------------------- */
};