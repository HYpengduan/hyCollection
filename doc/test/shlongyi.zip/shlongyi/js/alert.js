var Alert = {
	el: null,
	create: function (fn) {
		var that = this;
		this.el = $('<div class="mask"><div class="mask-content"><p class="title">温馨提示</p><p class="text">请先登录</p><span class="close">&times;</span></div></div>');
		$('body').append(this.el);

		// 给确定按钮添加点击事件
		this.el.find('.affirm').click(function () {
			Alert.hide();
			// 执行回调函数
			fn && fn();
		});

		// 给关闭按钮添加点击事件
		this.el.find('.close').click(function () {
			Alert.hide();
			// 执行回调函数
			fn && fn();
		});		
		return this;
	},
	show: function (sHtml, fn) {
		if(!Alert.el) {
			Alert.create(fn);
		}

		this.el.show().find('.text').html(sHtml);
	},
	hide: function () {
		this.el.hide();
	}
};